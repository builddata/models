### 知识图谱

![知识图谱](https://github.com/yunshuipiao/cheatsheets-ai-code/blob/master/img/%E7%9F%A5%E8%AF%86%E5%9B%BE%E8%B0%B1.webp)   
![数据科学家](https://github.com/yunshuipiao/cheatsheets-ai-code/blob/master/img/%E6%95%B0%E6%8D%AE%E7%A7%91%E5%AD%A6%E5%AE%B6.webp)   
![机器学习算法](https://github.com/yunshuipiao/cheatsheets-ai-code/blob/master/img/%E6%9C%BA%E5%99%A8%E5%AD%A6%E4%B9%A0%E7%AE%97%E6%B3%95.webp)  
![自然语言处理](https://github.com/yunshuipiao/cheatsheets-ai-code/blob/master/img/%E8%87%AA%E7%84%B6%E8%AF%AD%E8%A8%80%E5%A4%84%E7%90%86.webp)